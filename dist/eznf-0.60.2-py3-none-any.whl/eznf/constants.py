""" Constants used in the project """
TMP_FILENAME = 'tmp.cnf'
